#!/usr/bin/env python3
"""moonveil-devirt CLI — dynamic (trace-based) MoonVeil devirtualizer.

Usage:
    python3 devirt.py INPUT.lua [-o OUT.lua] [--report] [--fill-globals]
                       [--max-steps N] [--json trace.json]

Runs a MoonVeil-obfuscated script inside a sealed instrumented sandbox and
writes a readable behavioral reconstruction. It NEVER executes network or
filesystem side effects — those are stubbed and logged.
"""
from __future__ import annotations

import argparse
import json
import sys

from moonveildevirt import pipeline


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="moonveil-devirt", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input", help="path to the MoonVeil-obfuscated .lua file")
    ap.add_argument("-o", "--out", help="write reconstruction here (default: stdout)")
    ap.add_argument("--report", action="store_true", help="print fingerprint + trace stats to stderr")
    ap.add_argument("--fill-globals", action="store_true",
                    help="(lupa backend) proxy ALL unknown globals for exotic APIs")
    ap.add_argument("--backend", choices=["auto", "luau", "lupa"], default="auto",
                    help="execution engine: real Luau VM (best), lupa (fallback), or auto")
    ap.add_argument("--max-steps", type=int, default=5_000_000,
                    help="(lupa backend) VM step budget before aborting")
    ap.add_argument("--timeout", type=int, default=120,
                    help="(luau backend) wall-clock seconds before aborting")
    ap.add_argument("--no-download", action="store_true",
                    help="do not auto-download the luau binary if missing")
    ap.add_argument("--json", help="also dump the raw event trace as JSON here")
    args = ap.parse_args(argv)

    try:
        with open(args.input, "r", encoding="utf-8", errors="replace") as fh:
            source = fh.read()
    except OSError as exc:
        print(f"error: cannot read {args.input}: {exc}", file=sys.stderr)
        return 2

    try:
        rep = pipeline.devirtualize(
            source,
            sample_name=args.input,
            backend=args.backend,
            step_budget=args.max_steps,
            fill_globals=args.fill_globals,
            timeout=args.timeout,
            auto_download=not args.no_download,
        )
    except RuntimeError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 3

    if args.report:
        fp = rep.fingerprint
        print("== fingerprint ==", file=sys.stderr)
        print(f"  is MoonVeil: {fp.is_moonveil}", file=sys.stderr)
        for s in fp.signals:
            print(f"  signal: {s}", file=sys.stderr)
        for c in fp.components:
            print(f"  component: {c}", file=sys.stderr)
        print("== trace ==", file=sys.stderr)
        print(f"  backend={rep.backend} ok={rep.run.ok} "
              f"events={len(rep.run.events)} "
              f"steps={getattr(rep.run, 'steps', 0)} "
              f"limited={getattr(rep.run, 'limited', False)} "
              f"timed_out={getattr(rep.run, 'timed_out', False)}", file=sys.stderr)
        if getattr(rep.run, "error", None):
            print(f"  error: {rep.run.error}", file=sys.stderr)

    if args.json:
        payload = {
            "backend": rep.backend,
            "is_moonveil": rep.fingerprint.is_moonveil,
            "signals": rep.fingerprint.signals,
            "components": rep.fingerprint.components,
            "ok": rep.run.ok,
            "steps": getattr(rep.run, "steps", 0),
            "overrun": getattr(rep.run, "overrun", False),
            "limited": getattr(rep.run, "limited", False),
            "timed_out": getattr(rep.run, "timed_out", False),
            "error": getattr(rep.run, "error", None),
            "hot_line": getattr(rep.run, "hot_line", None),
            "events": [
                {"seq": e.seq, "category": e.category, "name": e.name, "args": e.args}
                for e in rep.run.events
            ],
        }
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, default=str)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(rep.reconstructed)
        print(f"wrote {args.out}", file=sys.stderr)
    else:
        sys.stdout.write(rep.reconstructed)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
