"""moonveil-devirt — a dynamic (trace-based) devirtualizer / behavior recovery
tool for scripts obfuscated with MoonVeil (getpolsec.com).

MoonVeil is a real VM-based Luau obfuscator (ChaCha20 + SHA-256 + base85 +
a flattened register VM). Static recovery of the original source is a
multi-week symbolic project. This tool takes the pragmatic, honest route the
KryptIT-style frameworks take: run the obfuscated script inside a sealed,
instrumented Lua sandbox, log every environment interaction + the VM's
dispatch profile, and reconstruct a readable *behavioral* Lua script from the
trace. Output is what-it-does, not a byte-perfect original.
"""

__version__ = "0.1.0"
__all__ = ["sandbox", "detect", "envlog", "reconstruct", "pipeline"]
