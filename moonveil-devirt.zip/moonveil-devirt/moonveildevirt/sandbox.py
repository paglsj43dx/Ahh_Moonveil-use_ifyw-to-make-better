"""Sealed, instrumented Lua sandbox that runs a MoonVeil script and records
every environment interaction plus a VM dispatch profile. Nothing the script
does can reach the real network or filesystem — those surfaces are stubbed.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .envlog import Event, lua_to_py

_HERE = os.path.dirname(os.path.abspath(__file__))


@dataclass
class RunResult:
    events: List[Event] = field(default_factory=list)
    line_hits: Dict[int, int] = field(default_factory=dict)
    line_seq: List[int] = field(default_factory=list)
    steps: int = 0
    overrun: bool = False
    ok: bool = True
    error: Optional[str] = None

    @property
    def hot_line(self) -> Optional[int]:
        if not self.line_hits:
            return None
        return max(self.line_hits, key=lambda k: self.line_hits[k])

    @property
    def hot_count(self) -> int:
        hl = self.hot_line
        return self.line_hits.get(hl, 0) if hl is not None else 0


def _load_lua_module(L, path):
    with open(path, "r", encoding="utf-8") as fh:
        src = fh.read()
    return L.execute(src)


def run(
    source: str,
    *,
    chunkname: str = "@moonveil",
    step_budget: int = 5_000_000,
    seq_cap: int = 4000,
    fill_globals: bool = False,
) -> RunResult:
    """Execute `source` in the instrumented sandbox and return a RunResult.

    Raises RuntimeError if lupa is unavailable.
    """
    try:
        from lupa import LuaError, LuaRuntime
    except Exception as exc:  # pragma: no cover
        raise RuntimeError(
            "lupa (a Lua runtime) is required for dynamic tracing. "
            "Install it with:  pip install lupa"
        ) from exc

    L = LuaRuntime(unpack_returned_tuples=True, register_eval=False)

    result = RunResult()
    counter = {"n": 0}

    def record(category, name, *args):
        counter["n"] += 1
        py_args = [lua_to_py(a) for a in args]
        result.events.append(Event(counter["n"], str(category), str(name), py_args))
        # keep the event log from exploding on pathological scripts
        return None

    stubs = _load_lua_module(L, os.path.join(_HERE, "stubs.lua"))
    instrument = _load_lua_module(L, os.path.join(_HERE, "instrument.lua"))

    # build an isolated environment table and populate it
    env = L.eval("{}")
    opts = L.eval("function(fg) return {fill_globals = fg} end")(fill_globals)
    stubs.install(env, record, opts)

    # compile the target with its _ENV bound to our sandbox env
    loader = L.eval(
        "function(src, name, env) local f, e = load(src, name, 't', env) return f, e end"
    )
    fn, err = loader(source, chunkname, env)
    if fn is None:
        result.ok = False
        result.error = f"compile error: {err}"
        return result

    tracer = instrument.make(step_budget, seq_cap)

    runner = L.eval("function(inst, st, f) inst.arm(st); local ok, e = pcall(f); inst.disarm(); return ok, e end")
    try:
        ok, err = runner(instrument, tracer, fn)
    except LuaError as exc:
        ok, err = False, str(exc)
    finally:
        try:
            instrument.disarm()
        except Exception:
            pass

    # pull trace state back into python
    try:
        hits = tracer.hits
        for k in list(hits.keys()):
            result.line_hits[int(k)] = int(hits[k])
        seq = tracer.seq
        result.line_seq = [int(seq[i]) for i in range(1, int(tracer.nseq) + 1)]
        result.steps = int(tracer.steps)
        result.overrun = bool(tracer.overrun)
    except Exception:
        pass

    result.ok = bool(ok)
    if not ok:
        result.error = str(err)
    return result
