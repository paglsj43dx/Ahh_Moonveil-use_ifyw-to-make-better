"""Real-Luau execution backend.

Runs a MoonVeil script under the *actual* Luau VM (the `luau` standalone CLI),
which matches MoonVeil's runtime semantics exactly (stock Lua 5.1/5.4/5.5 do
not — MoonVeil's decoder is calibrated to Luau and fails to complete on them).
The standalone CLI is itself sandboxed (no io / network / Roblox API), so we
only inject logging stubs via prelude.luau and parse the __MVEVENT__ lines it
prints. Fetched payloads (loadstring/load) are logged, never executed.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import urllib.request
import zipfile
from typing import List, Optional

from .envlog import Event

_HERE = os.path.dirname(os.path.abspath(__file__))
_CACHE = os.path.expanduser("~/.cache/luau")
_LUAU_URL = "https://github.com/luau-lang/luau/releases/download/0.740/luau-ubuntu.zip"


def find_luau() -> Optional[str]:
    """Locate a usable `luau` binary."""
    env = os.environ.get("MOONVEIL_LUAU")
    if env and os.path.isfile(env) and os.access(env, os.X_OK):
        return env
    cached = os.path.join(_CACHE, "luau")
    if os.path.isfile(cached) and os.access(cached, os.X_OK):
        return cached
    which = shutil.which("luau")
    if which:
        return which
    return None


def ensure_luau(auto_download: bool = True) -> Optional[str]:
    """Return a path to `luau`, downloading a prebuilt Linux binary if needed."""
    found = find_luau()
    if found:
        return found
    if not auto_download:
        return None
    try:
        os.makedirs(_CACHE, exist_ok=True)
        zip_path = os.path.join(_CACHE, "luau.zip")
        urllib.request.urlretrieve(_LUAU_URL, zip_path)
        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(_CACHE)
        binp = os.path.join(_CACHE, "luau")
        if os.path.isfile(binp):
            os.chmod(binp, 0o755)
            return binp
    except Exception:
        return None
    return None


def _unescape(s: str) -> str:
    out = []
    i = 0
    while i < len(s):
        c = s[i]
        if c == "\\" and i + 1 < len(s):
            nxt = s[i + 1]
            out.append({"t": "\t", "n": "\n", "r": "\r", "\\": "\\"}.get(nxt, nxt))
            i += 2
        else:
            out.append(c)
            i += 1
    return "".join(out)


def _coerce(v: str):
    """Turn a stringified Lua scalar back into a python value where obvious."""
    if v == "nil":
        return None
    if v == "true":
        return True
    if v == "false":
        return False
    try:
        f = float(v)
        return int(f) if f.is_integer() else f
    except ValueError:
        return v


class LuauResult:
    def __init__(self):
        self.events: List[Event] = []
        self.ok: bool = True
        self.error: Optional[str] = None
        self.limited: bool = False       # hit the event cap (hang / poll loop)
        self.timed_out: bool = False
        self.backend: str = "luau"
        self.raw_stderr: str = ""

    # duck-type compatibility with sandbox.RunResult where used
    line_hits: dict = {}
    line_seq: list = []
    steps: int = 0
    overrun: bool = False
    hot_line = None
    hot_count = 0


def run(
    source: str,
    *,
    luau_path: Optional[str] = None,
    timeout: int = 120,
    auto_download: bool = True,
) -> LuauResult:
    res = LuauResult()
    binp = luau_path or ensure_luau(auto_download=auto_download)
    if not binp:
        res.ok = False
        res.error = ("no `luau` binary found. Set MOONVEIL_LUAU=/path/to/luau, "
                     "put it on PATH, or allow auto-download.")
        return res

    with open(os.path.join(_HERE, "prelude.luau"), encoding="utf-8") as fh:
        prelude = fh.read()

    with tempfile.NamedTemporaryFile("w", suffix=".luau", delete=False, encoding="utf-8") as tf:
        tf.write(prelude)
        tf.write("\n")
        tf.write(source)
        combined = tf.name

    try:
        proc = subprocess.run(
            [binp, combined],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        stdout, stderr = proc.stdout, proc.stderr
    except subprocess.TimeoutExpired as exc:
        res.timed_out = True
        stdout = exc.stdout or ""
        stderr = exc.stderr or ""
        if isinstance(stdout, bytes):
            stdout = stdout.decode("utf-8", "replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode("utf-8", "replace")
    finally:
        try:
            os.unlink(combined)
        except OSError:
            pass

    res.raw_stderr = (stderr or "")[-4000:]
    seq = 0
    for line in stdout.splitlines():
        if line.startswith("__MVLIMIT__"):
            res.limited = True
            continue
        if line == "__MVREADY__":
            continue
        if not line.startswith("__MVEVENT__"):
            continue
        parts = line.split("\t")
        if len(parts) < 3:
            continue
        cat, name = parts[1], parts[2]
        args = [_coerce(_unescape(p)) for p in parts[3:]]
        seq += 1
        res.events.append(Event(seq, cat, name, args))

    # a Luau runtime error that isn't our own stop-sentinel is a real failure
    if stderr and "__mv_stop__" not in stderr and not res.events:
        res.ok = False
        res.error = stderr.strip().splitlines()[0] if stderr.strip() else "luau error"
    return res
