"""Glue: fingerprint -> execute (real Luau, else lupa) -> behavioral reconstruction."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from . import detect, luaubackend, reconstruct, sandbox


@dataclass
class DevirtReport:
    fingerprint: detect.Fingerprint
    run: object            # LuauResult or sandbox.RunResult
    reconstructed: str
    backend: str


def devirtualize(
    source: str,
    *,
    sample_name: str = "<input>",
    backend: str = "auto",       # "auto" | "luau" | "lupa"
    step_budget: int = 5_000_000,
    seq_cap: int = 4000,
    fill_globals: bool = False,
    timeout: int = 120,
    auto_download: bool = True,
) -> DevirtReport:
    fp = detect.fingerprint(source)

    chosen = backend
    if backend == "auto":
        chosen = "luau" if luaubackend.ensure_luau(auto_download=auto_download) else "lupa"

    if chosen == "luau":
        run = luaubackend.run(source, timeout=timeout, auto_download=auto_download)
        used = "luau"
    else:
        run = sandbox.run(
            source,
            step_budget=step_budget,
            seq_cap=seq_cap,
            fill_globals=fill_globals,
        )
        used = "lupa"

    text = reconstruct.reconstruct(run, sample_name=sample_name)
    return DevirtReport(fingerprint=fp, run=run, reconstructed=text, backend=used)
