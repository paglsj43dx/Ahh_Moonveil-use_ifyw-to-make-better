-- instrument.lua : execution tracer built on debug.sethook.
--
-- We capture two things while the MoonVeil VM runs:
--   * a line-hit profile  (which source lines execute, how often)  -> finds
--     the dispatcher hot-loop and how many opcodes were interpreted.
--   * a bounded line sequence (first N line events)                -> shows
--     the dispatch order early in execution.
-- The same hook enforces a hard STEP BUDGET so a hostile/infinite VM loop
-- cannot hang the host.

local M = {}
local dbg = debug   -- capture before the sandbox nils it out

function M.make(step_budget, seq_cap)
    step_budget = step_budget or 5000000
    seq_cap = seq_cap or 4000
    local state = {
        hits = {},
        seq = {},
        nseq = 0,
        steps = 0,
        overrun = false,
    }
    local hits = state.hits
    local seq = state.seq
    local function hook(event, line)
        state.steps = state.steps + 1
        if state.steps > step_budget then
            state.overrun = true
            error("moonveil-devirt: step budget exceeded (" .. step_budget .. ")", 2)
        end
        if line then
            hits[line] = (hits[line] or 0) + 1
            if state.nseq < seq_cap then
                state.nseq = state.nseq + 1
                seq[state.nseq] = line
            end
        end
    end
    state.hook = hook
    return state
end

function M.arm(state)
    dbg.sethook(state.hook, "l")
end

function M.disarm()
    dbg.sethook()
end

return M
