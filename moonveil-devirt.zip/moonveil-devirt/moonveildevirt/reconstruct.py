"""Turn a recorded interaction trace into a readable *behavioral* Lua script.

This is the "not fully, env-logged" reconstruction the tool targets: it does
not recover MoonVeil's original identifiers or control flow, it recovers what
the script *did* to its environment, and rolls repeated interactions back into
loops so the output reads like source instead of a flat log.
"""
from __future__ import annotations

from typing import Any, List, Optional, Tuple

from .envlog import Event, fmt_arg
from .sandbox import RunResult

LOOP_MIN = 3  # minimum repeats before we roll a run into a for-loop


def _arith(values: List[Any]) -> Optional[Tuple[float, float]]:
    """If values form an arithmetic progression of numbers, return (start, step)."""
    if not all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in values):
        return None
    if len(values) < 2:
        return (values[0], 0)
    step = values[1] - values[0]
    for i in range(2, len(values)):
        if values[i] - values[i - 1] != step:
            return None
    return (values[0], step)


def _num(x: float) -> str:
    return str(int(x)) if float(x).is_integer() else str(x)


def _arg_expr(loopvar: str, values: List[Any]) -> Optional[str]:
    """Express one argument position across a run as a Lua expression in loopvar,
    or None if the position is neither constant nor a clean progression."""
    if all(v == values[0] for v in values):
        return fmt_arg(values[0])  # constant
    prog = _arith(values)
    if prog is None:
        return None
    start, step = prog
    if step == 1 and start == 1:
        return loopvar
    if step == 1:
        return f"({loopvar} + {_num(start - 1)})"
    if step == 0:
        return fmt_arg(start)
    base = f"({loopvar} - 1) * {_num(step)}"
    if start == 0:
        return f"({base})"
    return f"({_num(start)} + {base})"


def _try_roll(events: List[Event], i: int) -> Optional[Tuple[int, str]]:
    """Attempt to roll a run of identical-shape events starting at index i.
    Returns (num_consumed, lua_block) or None."""
    first = events[i]
    j = i
    while (
        j < len(events)
        and events[j].category == first.category
        and events[j].name == first.name
        and len(events[j].args) == len(first.args)
    ):
        j += 1
    run = events[i:j]
    if len(run) < LOOP_MIN:
        return None
    loopvar = "i"
    exprs = []
    for p in range(len(first.args)):
        col = [e.args[p] for e in run]
        expr = _arg_expr(loopvar, col)
        if expr is None:
            return None
        exprs.append(expr)
    varies = not all(e == fmt_arg(run[0].args[p]) for p, e in enumerate(exprs))
    body = f'{first.name}({", ".join(exprs)})'
    if not varies:
        # identical calls repeated -> a poll / hang loop
        note = "  -- repeated (poll/wait loop)"
        if first.name in ("task.wait", "wait") or "wait" in first.name.lower():
            note = "  -- busy/hang loop (script spins here indefinitely without a key)"
        block = f"while true do{note}\n    {first.call_source()}\nend"
        return (len(run), block)
    block = f"for {loopvar} = 1, {len(run)} do\n    {body}\nend"
    return (len(run), block)


def reconstruct(result: RunResult, *, sample_name: str = "<input>") -> str:
    lines: List[str] = []
    ap = lines.append

    ap("-- ============================================================")
    ap("-- MoonVeil behavioral reconstruction (moonveil-devirt)")
    ap("-- ------------------------------------------------------------")
    ap("-- This is NOT the original source. It is a readable trace of")
    ap("-- what the obfuscated script did to its environment, captured")
    ap("-- by running it inside a sealed instrumented sandbox.")
    ap(f"-- source     : {sample_name}")
    ap(f"-- backend    : {getattr(result, 'backend', 'lupa')}")
    if getattr(result, "steps", 0):
        ap(f"-- vm steps   : {result.steps}")
    if result.hot_line is not None:
        ap(f"-- dispatcher : source line {result.hot_line} ran {result.hot_count} times (VM hot-loop)")
    ap(f"-- events     : {len(result.events)} environment interactions captured")
    if not result.ok:
        ap(f"-- NOTE       : execution ended with an error: {result.error}")
    if result.overrun:
        ap("-- WARNING    : step budget hit — trace may be incomplete (raise --max-steps)")
    if getattr(result, "limited", False):
        ap("-- NOTE       : event cap reached — script kept looping (likely a hang/poll loop).")
    if getattr(result, "timed_out", False):
        ap("-- NOTE       : execution timed out (script did not terminate on its own).")
    ap("-- ============================================================")
    ap("")

    # behavioral summary (triage view) ------------------------------------
    cats: dict[str, int] = {}
    for e in result.events:
        cats[e.category] = cats.get(e.category, 0) + 1
    interesting = {k: v for k, v in cats.items() if k not in ("output",)}
    if interesting:
        ap("--[[ behavior summary")
        for cat in sorted(interesting):
            ap(f"     {cat:<12}: {interesting[cat]} call(s)")
        for cat in ("network", "codeload", "filesystem"):
            hits = [e for e in result.events if e.category == cat]
            for e in hits[:8]:
                ap(f"       -> {e.call_source()}")
        ap("]]")
        ap("")

    if not result.events:
        ap("-- (no environment interactions were recorded)")
        return "\n".join(lines) + "\n"

    # reconstructed body with loop-rolling --------------------------------
    i = 0
    events = result.events
    while i < len(events):
        rolled = _try_roll(events, i)
        if rolled:
            consumed, block = rolled
            ap(block)
            i += consumed
        else:
            ap(events[i].call_source())
            i += 1

    return "\n".join(lines) + "\n"
