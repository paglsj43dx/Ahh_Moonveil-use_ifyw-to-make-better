"""Lightweight static fingerprinting: is this MoonVeil, and which components?"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List

BANNER = re.compile(r"obfuscated with MoonVeil", re.I)
GETPOLSEC = re.compile(r"getpolsec\.com", re.I)


@dataclass
class Fingerprint:
    is_moonveil: bool = False
    signals: List[str] = field(default_factory=list)
    components: List[str] = field(default_factory=list)


# constant fingerprints confirmed from the analyzed sample
_SHA256_INIT = ["1779033703", "3144134277", "1013904242", "2773480762",
                "1359893119", "2600822924", "528734635", "1541459225"]
_CHACHA = ["16", "12", "8", "7"]  # quarter-round rotations (weak signal alone)


def fingerprint(source: str) -> Fingerprint:
    fp = Fingerprint()
    if BANNER.search(source):
        fp.is_moonveil = True
        fp.signals.append("MoonVeil banner comment present")
    if GETPOLSEC.search(source):
        fp.is_moonveil = True
        fp.signals.append("getpolsec.com reference present")

    hit = sum(1 for c in _SHA256_INIT if c in source)
    if hit >= 4:
        fp.components.append(f"SHA-256 (matched {hit}/8 init constants)")
    if re.search(r":l\(\{", source) or re.search(r"\}\)\s*:\s*\w+\(\{", source):
        fp.components.append("MoonVeil dispatcher shape ( {...}:name({...}, ...) )")
        fp.is_moonveil = fp.is_moonveil or True
    if "bit32" in source:
        fp.components.append("bit32 arithmetic (constant-hiding / crypto)")
    if re.search(r"while true do", source) and re.search(r"elseif", source):
        fp.components.append("flattened state-machine dispatcher (register VM)")

    if not fp.signals and fp.components:
        fp.signals.append("no banner, but VM/crypto shape resembles MoonVeil")
    return fp
