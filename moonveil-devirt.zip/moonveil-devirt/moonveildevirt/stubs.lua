-- stubs.lua : the instrumented environment the MoonVeil script runs inside.
-- Everything dangerous (network / filesystem / code-loading / Roblox API) is
-- replaced with a logging stub that RECORDS the interaction and returns a
-- benign value. Nothing ever touches the real machine. The plain Lua stdlib
-- (string/table/math/...) is left intact so the embedded VM still computes
-- correctly and its *behavior* is what we capture.

local M = {}

-- ---------------------------------------------------------------------------
-- bit32 shim : Luau (Lua 5.1 base) ships bit32; host Lua 5.4/5.5 removed it.
-- ---------------------------------------------------------------------------
local function ensure_bit32(env)
    if env.bit32 then return end
    local MASK = 0xFFFFFFFF
    local function norm(x) return math.floor(x) & MASK end
    local b = {}
    b.band    = function(a, c, ...) local r = norm(a) & norm(c); for _, v in ipairs({...}) do r = r & norm(v) end return r end
    b.bor     = function(a, c, ...) local r = norm(a) | norm(c); for _, v in ipairs({...}) do r = r | norm(v) end return r end
    b.bxor    = function(a, c, ...) local r = norm(a) ~ norm(c); for _, v in ipairs({...}) do r = r ~ norm(v) end return r end
    b.bnot    = function(a) return (~norm(a)) & MASK end
    b.lshift  = function(a, n) if n <= -32 or n >= 32 then return 0 end if n < 0 then return (norm(a) >> -n) end return (norm(a) << n) & MASK end
    b.rshift  = function(a, n) if n <= -32 or n >= 32 then return 0 end if n < 0 then return (norm(a) << -n) & MASK end return (norm(a) >> n) end
    b.arshift = function(a, n) local x = norm(a); if n < 0 then return (x << -n) & MASK end if n >= 32 then return (x & 0x80000000) ~= 0 and MASK or 0 end return x >> n end
    b.lrotate = function(a, n) n = n % 32; local x = norm(a); return ((x << n) | (x >> (32 - n))) & MASK end
    b.rrotate = function(a, n) n = n % 32; local x = norm(a); return ((x >> n) | (x << (32 - n))) & MASK end
    b.extract = function(a, f, w) w = w or 1; return (norm(a) >> f) & ((1 << w) - 1) end
    b.replace = function(a, v, f, w) w = w or 1; local m = ((1 << w) - 1) << f; return (norm(a) & ~m) | ((norm(v) << f) & m) end
    b.countlz = function(a) local x = norm(a); for i = 31, 0, -1 do if (x >> i) & 1 == 1 then return 31 - i end end return 32 end
    b.countrz = function(a) local x = norm(a); if x == 0 then return 32 end for i = 0, 31 do if (x >> i) & 1 == 1 then return i end end return 32 end
    env.bit32 = b
end

-- ---------------------------------------------------------------------------
-- universal logging proxy : indexing / calling it never errors, it just logs.
-- Used for the Roblox + executor API surface so unknown code can run without
-- crashing on nil, while every reach into that surface is recorded.
-- ---------------------------------------------------------------------------
-- shared registry so ANY proxy can recognise ANY other proxy (weak keys)
local PROXIES = setmetatable({}, { __mode = "k" })

local function make_proxy(path, record, category)
    local mt = {}
    mt.__index = function(_, k)
        return make_proxy(path .. "." .. tostring(k), record, category)
    end
    mt.__newindex = function() end
    mt.__call = function(_, ...)
        -- strip an obvious self (`a:b()` passes a proxy back as the first arg)
        local n = select("#", ...)
        local first = ...
        local args, cnt
        if n >= 1 and type(first) == "table" and PROXIES[first] then
            args, cnt = { select(2, ...) }, n - 1
        else
            args, cnt = { ... }, n
        end
        record(category or "api", path, table.unpack(args, 1, cnt))
        return make_proxy(path .. "()", record, category)
    end
    mt.__tostring = function() return path end
    mt.__concat = function(a, c) return tostring(a) .. tostring(c) end
    local p = setmetatable({}, mt)
    PROXIES[p] = true
    return p
end
M.make_proxy = make_proxy

-- ---------------------------------------------------------------------------
-- install(env, record, opts) : populate a fresh environment table.
--   record(category, name, ...)  -- python callback, records one interaction
-- ---------------------------------------------------------------------------
function M.install(env, record, opts)
    opts = opts or {}
    ensure_bit32(env)

    -- output --------------------------------------------------------------
    env.print = function(...) record("output", "print", ...) end
    env.warn  = function(...) record("output", "warn", ...) end
    env.error = function(msg, lvl) record("output", "error", msg); return error(msg, lvl) end

    -- code loading (log the payload, DO NOT execute it) -------------------
    local function loader(name)
        return function(chunk, ...)
            record("codeload", name, tostring(chunk))
            -- return a function that, when called, does nothing (payload not run)
            return function() end
        end
    end
    env.loadstring = loader("loadstring")
    env.load       = loader("load")
    env.require     = function(m) record("codeload", "require", tostring(m)); return make_proxy("require()", record, "codeload") end
    env.dofile      = function(f) record("codeload", "dofile", f) end
    env.loadfile    = function(f) record("codeload", "loadfile", f); return function() end end

    -- network / http (executor + Roblox) ---------------------------------
    for _, n in ipairs({ "request", "http_request", "httprequest" }) do
        env[n] = function(t) record("network", n, t); return make_proxy(n .. "()", record, "network") end
    end
    env.syn = make_proxy("syn", record, "network")
    env.http = make_proxy("http", record, "network")

    -- filesystem (executor) ----------------------------------------------
    for _, n in ipairs({ "readfile", "writefile", "appendfile", "makefolder",
                         "delfile", "delfolder", "listfiles", "isfile", "isfolder", "loadfile" }) do
        env[n] = function(...) record("filesystem", n, ...); return "" end
    end

    -- environment / hooking (executor) -----------------------------------
    for _, n in ipairs({ "getgenv", "getrenv", "getsenv", "getfenv", "setfenv",
                         "hookfunction", "hookmetamethod", "getrawmetatable",
                         "setrawmetatable", "getnamecallmethod", "checkcaller",
                         "getconnections", "firesignal", "getgc", "getreg",
                         "getscriptclosure", "getscripthash", "identifyexecutor",
                         "newcclosure", "islclosure", "iscclosure", "clonefunction" }) do
        env[n] = function(...) record("environment", n, ...); return make_proxy(n .. "()", record, "environment") end
    end

    -- Roblox globals ------------------------------------------------------
    env.game      = make_proxy("game", record, "roblox")
    env.workspace = make_proxy("workspace", record, "roblox")
    env.script    = make_proxy("script", record, "roblox")
    env.Instance  = make_proxy("Instance", record, "roblox")
    env.Vector3   = make_proxy("Vector3", record, "roblox")
    env.Vector2   = make_proxy("Vector2", record, "roblox")
    env.CFrame    = make_proxy("CFrame", record, "roblox")
    env.Color3    = make_proxy("Color3", record, "roblox")
    env.UDim2     = make_proxy("UDim2", record, "roblox")
    env.Enum      = make_proxy("Enum", record, "roblox")
    env.task      = setmetatable({
        wait   = function(t) record("task", "wait", t) end,
        spawn  = function(f, ...) record("task", "spawn"); if type(f) == "function" then f(...) end end,
        defer  = function(f, ...) record("task", "defer"); if type(f) == "function" then f(...) end end,
        delay  = function(_, f, ...) record("task", "delay"); if type(f) == "function" then f(...) end end,
    }, { __index = function(_, k) return make_proxy("task." .. tostring(k), record, "task") end })
    env.wait  = function(t) record("task", "wait", t) end
    env.spawn = function(f, ...) record("task", "spawn"); if type(f) == "function" then f(...) end end
    env.delay = function(_, f, ...) record("task", "delay"); if type(f) == "function" then f(...) end end
    env.tick  = function() return 0 end
    env.time  = function() return 0 end

    -- neuter raw io/os side effects, keep pure helpers -------------------
    env.io = nil
    env.os = {
        time = function() return 0 end, clock = function() return 0 end,
        date = function() return "1970-01-01" end, getenv = function() return nil end,
        difftime = function(a, b) return (a or 0) - (b or 0) end,
    }

    -- safe stdlib passthrough --------------------------------------------
    for _, n in ipairs({ "string", "table", "math", "coroutine", "utf8",
                         "tostring", "tonumber", "type", "pairs", "ipairs",
                         "next", "select", "pcall", "xpcall", "assert",
                         "setmetatable", "getmetatable", "rawget", "rawset",
                         "rawequal", "rawlen", "unpack", "_VERSION" }) do
        env[n] = _G[n]
    end
    if env.unpack == nil and env.table then env.unpack = env.table.unpack end

    -- optional: fill any *other* unknown global with a proxy (robust mode)
    if opts.fill_globals then
        setmetatable(env, {
            __index = function(_, k)
                return make_proxy(tostring(k), record, "unknown")
            end,
        })
    end

    env._G = env
    env._ENV = env
    env.getfenv = env.getfenv or function() return env end
    return env
end

return M
