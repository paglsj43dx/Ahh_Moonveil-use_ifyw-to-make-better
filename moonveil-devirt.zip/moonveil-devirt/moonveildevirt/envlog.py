"""Event model + Lua->Python value conversion for the interaction log."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List


def lua_to_py(v: Any, _depth: int = 0) -> Any:
    """Best-effort convert a value coming back from lupa into a plain Python
    value suitable for logging/serialisation. Tables become dict/list; deeply
    nested or cyclic structures are truncated."""
    # lupa lua tables expose .items()/.values(); detect duck-typed
    if v is None or isinstance(v, (bool, int, float, str)):
        return v
    if _depth > 4:
        return "<...>"
    # lupa function / callable
    tname = type(v).__name__
    if "function" in tname.lower():
        return "<function>"
    # try table-like
    try:
        keys = list(v.keys())  # type: ignore[attr-defined]
    except Exception:
        try:
            return str(v)
        except Exception:
            return f"<{tname}>"
    # array vs dict
    if keys and all(isinstance(k, int) for k in keys) and keys == list(range(1, len(keys) + 1)):
        return [lua_to_py(v[k], _depth + 1) for k in keys]
    out = {}
    for k in keys[:64]:
        try:
            out[str(k)] = lua_to_py(v[k], _depth + 1)
        except Exception:
            out[str(k)] = "<?>"
    return out


def fmt_arg(a: Any) -> str:
    """Render one argument the way it would appear in Lua source."""
    if isinstance(a, str):
        return '"' + a.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'
    if isinstance(a, bool):
        return "true" if a else "false"
    if a is None:
        return "nil"
    if isinstance(a, float) and a.is_integer():
        return str(int(a))
    if isinstance(a, (list, dict)):
        return _fmt_table(a)
    return str(a)


def _fmt_table(t: Any) -> str:
    if isinstance(t, list):
        return "{" + ", ".join(fmt_arg(x) for x in t) + "}"
    parts = []
    for k, val in t.items():
        parts.append(f"{k} = {fmt_arg(val)}")
    return "{" + ", ".join(parts) + "}"


@dataclass
class Event:
    seq: int
    category: str  # output | network | filesystem | codeload | environment | roblox | task | api | error
    name: str      # e.g. "print", "game.HttpGet", "loadstring"
    args: List[Any] = field(default_factory=list)

    def call_source(self) -> str:
        return f'{self.name}({", ".join(fmt_arg(a) for a in self.args)})'

    def summary(self) -> str:
        return f"[{self.category}] {self.call_source()}"
