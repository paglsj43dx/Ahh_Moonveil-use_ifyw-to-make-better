-- ============================================================
-- MoonVeil behavioral reconstruction (moonveil-devirt)
-- ------------------------------------------------------------
-- This is NOT the original source. It is a readable trace of
-- what the obfuscated script did to its environment, captured
-- by running it inside a sealed instrumented sandbox.
-- source     : samples/real_sample.lua
-- backend    : luau
-- events     : 6000 environment interactions captured
-- NOTE       : event cap reached — script kept looping (likely a hang/poll loop).
-- ============================================================

--[[ behavior summary
     environment : 1 call(s)
     roblox      : 6 call(s)
     task        : 5992 call(s)
]]

getgenv()
warn("[ PolSec ] Error: No key was provided.")
game.GetService("Players")
game.GetService().LocalPlayer.Kick("No key was provided.")
game.GetService("CoreGui")
game.GetService().FindFirstChild("RobloxPromptGui")
game.GetService().FindFirstChild().FindFirstChild("promptOverlay")
game.GetService().FindFirstChild().FindFirstChild().FindFirstChild("ErrorPrompt")
while true do  -- busy/hang loop (script spins here indefinitely without a key)
    wait(9999)
end
