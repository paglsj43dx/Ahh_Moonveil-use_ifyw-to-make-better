-- This script is obfuscated with MoonVeil [https://getpolsec.com]
-- (SYNTHETIC MoonVeil-shaped sample, written by hand for offline testing of
--  the devirtualizer tracer. It mimics MoonVeil's overall shape: a banner,
--  an encrypted constant pool, and a register-based VM dispatcher. The hidden
--  program is:  local msg="hello from moonveil"; for i=1,3 do print(i,msg) end )

return (function(...)
    -- ---- encrypted constant pool (per-char xor keystream, MoonVeil-style) ----
    local Ua = { O = {}, key = { 0x4D, 0x56, 0x21, 0x37 } }
    local enc = { 37,51,77,91,34,118,71,69,34,59,1,90,34,57,79,65,40,63,77 }
    Ua.O[1] = (function()
        local t = {}
        for i = 1, #enc do
            t[i] = string.char((function(a, b) -- decrypt handler hidden behind identity
                local x = a
                local y = b
                return (x ~ y)   -- bitwise xor
            end)(enc[i], Ua.key[((i - 1) % #Ua.key) + 1]))
        end
        return table.concat(t)
    end)()
    Ua.O[2] = "print"

    -- ---- register VM bytecode -------------------------------------------------
    -- op codes: 1 LOADK a k | 2 GETGLOBAL a k | 4 LOADN a imm
    --           5 FORPREP a sBx | 6 FORLOOP a sBx | 7 CALL a nargs
    --           8 MOVE a b | 9 RETURN
    local code = {
        { 1, 1, 1 },        -- R1 = K[1]  ("hello from moonveil")
        { 4, 2, 1 },        -- R2 = 1      (for init)
        { 4, 3, 3 },        -- R3 = 3      (for limit)
        { 4, 4, 1 },        -- R4 = 1      (for step)
        { 5, 2, 4 },        -- FORPREP R2 -> jump to +4 (the FORLOOP)
        { 2, 6, 2 },        -- R6 = _G["print"]
        { 8, 7, 5 },        -- R7 = R5 (loop var i)
        { 8, 8, 1 },        -- R8 = R1 (msg)
        { 7, 6, 2 },        -- CALL R6 with 2 args (R7,R8)
        { 6, 2, -5 },       -- FORLOOP R2 -> back to body start if not done
        { 9 },              -- RETURN
    }

    -- ---- flattened dispatcher (register machine) -----------------------------
    local R = {}
    local pc = 1
    local ub = 0            -- MoonVeil-style opaque state accumulator
    while true do
        local ins = code[pc]
        pc = pc + 1
        local op = ins[1]
        ub = (ub + op * 7 + 3) % 1000003   -- opaque next-state arithmetic
        if op == 1 then
            R[ins[2]] = Ua.O[ins[3]]
        elseif op == 2 then
            R[ins[2]] = _G[Ua.O[ins[3]]]
        elseif op == 4 then
            R[ins[2]] = ins[3]
        elseif op == 5 then                 -- FORPREP
            R[ins[2]] = R[ins[2]] - R[ins[2] + 2]
            pc = pc + ins[3]
        elseif op == 6 then                 -- FORLOOP
            R[ins[2]] = R[ins[2]] + R[ins[2] + 2]
            if R[ins[2]] <= R[ins[2] + 1] then
                R[ins[2] + 3] = R[ins[2]]
                pc = pc + ins[3]
            end
        elseif op == 7 then                 -- CALL
            local fn = R[ins[2]]
            local args = {}
            for k = 1, ins[3] do args[k] = R[ins[2] + k] end
            fn(table.unpack(args))
        elseif op == 8 then                 -- MOVE
            R[ins[2]] = R[ins[3]]
        elseif op == 9 then                 -- RETURN
            break
        end
    end
end)(...)
