# moonveil-devirt — design notes & MoonVeil teardown

## 1. What MoonVeil actually is (verified from a real sample)

Banner: `-- This script is obfuscated with MoonVeil [https://getpolsec.com]`
Shape: `return({ <~50 handler/closure fns> }):l({<56-name alias list>}, "la", ...)`

Confirmed components:

| Component | Evidence | Role |
|-----------|----------|------|
| **SHA-256** | init constants `1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225` + full round-constant table match | integrity / anti-tamper |
| **ChaCha20 family** | quarter-round rotations `16/12/8/7`; state init `880556477, 3156566354, 2563493392, 2501117568` (non-standard → keyed variant) | payload stream cipher |
| **base85 / Z85** | 85-char alphabet `0123456789ABC…xyz!#$%&()*+-;<=>?@^_\`{|}~` | encodes the blob |
| **xxhash-style mix** | 6-round avalanche | key/index derivation |
| **Register VM** | huge flattened `while true do if ub<N ...` dispatcher, arithmetic next-state on `ub`, constants via `Ua.O[..]/Ua.U[..]/Ua.aa[..]/Ua.fa[..]` with per-call decrypt handlers hiding simple ops behind `bit32` identities | executes custom bytecode |

Pipeline: **base85 → ChaCha20 decrypt → SHA-256 integrity → register-VM interprets bytecode.** The original program never exists as text.

## 2. Why we chose dynamic (trace-based) over static

Static devirtualization means: lift MoonVeil's hundreds of opcodes to an IR, then
to Lua. That's a multi-week symbolic project and brittle across versions. The VM
also decrypts its own constants at runtime — so **running it hands us the
plaintext for free.** The pragmatic, honest win is to execute it under
instrumentation and reconstruct behavior. This is what serious deobfuscation
frameworks (e.g. KryptIT-style) do: ship an instrumented interpreter and trace.

Trade-off we accept: we only see code paths that **execute** in the trace. Dead
branches / input-gated logic won't appear unless triggered. That's the documented
limit of any dynamic approach.

### 2a. Why the host runtime MUST be real Luau (measured, not assumed)

MoonVeil's constant-pool decoder is calibrated to Luau's number model (Lua 5.1
lineage — **all numbers are doubles, no integer subtype**). We tried the sample on
every runtime lupa bundles:

| host       | number model            | result on the real sample                |
|------------|-------------------------|------------------------------------------|
| Lua 5.5    | int + float subtypes    | dies: `call nil 'kb'` in decoder         |
| Lua 5.2    | double-only, native bit32 | dies deeper: `call nil 'k'` (via `t`)  |
| Lua 5.1    | double-only (Luau base) | dies deepest: `call nil 'p'` (via C `k`) |
| **real Luau 0.740** | **native**     | **runs to completion — full behavior** ✅ |

The failure point *moving* per host proves it's a semantics-calibration issue, not
a missing global (we verified zero missing globals are read before failure). So the
default backend shells out to the official `luau` standalone binary. The CLI is
already sandboxed (no io/net/Roblox), so we only inject `prelude.luau` logging
stubs and parse its `__MVEVENT__` stdout. `loadstring`/`load` payloads are logged,
never executed. A `MAX_EVENTS` cap + subprocess timeout bound no-key hang loops.

### 2b. What the real sample turned out to be

A **PolSec key-gated loader**. With no key it: `getgenv()` → `warn("[ PolSec ]
Error: No key was provided.")` → `game:GetService("Players").LocalPlayer:Kick(...)`
→ shows a CoreGui `ErrorPrompt` → `while true do wait(9999) end` (hangs). The
protected payload is behind the key check and does not run without a valid key.

## 3. Architecture

```
detect.py        static fingerprint (banner / sha256 consts / vm shape)
stubs.lua        sealed environment: bit32 shim, logged+faked roblox/executor
                 api, sealed io/os, real stdlib passthrough
instrument.lua   debug.sethook line profiler + hard step budget (anti-hang)
sandbox.py       lupa runtime: binds _ENV to the sealed env, runs, collects
                 events + dispatch profile   (NEVER runs loadstring payloads)
envlog.py        event model + Lua→Python value marshalling + Lua-literal fmt
reconstruct.py   trace → readable lua; rolls arithmetic-progression repeats
                 into for-loops; emits triage summary
pipeline.py      glue;  devirt.py = CLI
```

## 4. Safety model

- No real network/filesystem: those globals are stubs that log and return benign
  values. `io` is removed; `os` is a pure/no-op subset.
- `loadstring`/`load`/`require`/`dofile` are **logged but never executed** — a
  fetched stage-2 payload is captured as data, not run.
- Hard step budget aborts hostile infinite VM loops.
- lupa runs Lua in-process but with no access surface beyond what stubs.lua grants.

## 5. Roadmap → full static devirtualizer

This v0.1 is the **dynamic** stage. A real static devirt needs, in order:

1. **Corpus** — several MoonVeil samples (one is not enough to map the opcode set).
2. **Constant-pool extractor** — hook `Ua.O/U/aa/fa` decrypt handlers, dump the
   decrypted constant table + the raw VM bytecode array. (`--json` already gives
   the interaction trace; add a bytecode-dump hook here.)
3. **Opcode semantics map** — for each `ub` state, record (reads, writes,
   next-state) via micro-tracing → classify into LOADK/GETGLOBAL/CALL/arith/jump.
4. **Lifter** — bytecode → IR (SSA), fold the opaque `bit32` constant identities.
5. **Structurer** — reuse the luast toolchain's dominator/loop recovery + SCCP.
6. **Emitter** — IR → readable Lua.

Steps 5–6 can literally reuse `luast-deob`'s `structure.py` / `polish.py` /
`printer.py`. That's the path if/when the corpus exists.

## 6. Known limitations (v0.1)

- Host Lua is 5.5 (via lupa); Luau-only syntax (`+=`, `continue`, type
  annotations) won't `load`. Machine-generated MoonVeil output is mostly plain,
  but a Luau→Lua pre-pass may be needed for some samples.
- Line-hit profile aggregates across chunks (line numbers can collide); it's a
  hot-loop *indicator*, not a per-instruction map.
- Reconstruction is behavioral: names/exact CFG are not recovered by design.
