import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from moonveildevirt import detect, reconstruct
from moonveildevirt.envlog import Event

lupa = pytest.importorskip("lupa", reason="lupa (Lua runtime) required for dynamic tracing tests")

from moonveildevirt import pipeline, sandbox  # noqa: E402

SAMPLES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "samples")


def _read(name):
    with open(os.path.join(SAMPLES, name), encoding="utf-8") as fh:
        return fh.read()


# ---- static fingerprinting -------------------------------------------------

def test_detect_banner():
    fp = detect.fingerprint(_read("synth_vm.lua"))
    assert fp.is_moonveil
    assert any("banner" in s for s in fp.signals)


def test_detect_negative():
    fp = detect.fingerprint('print("just a normal script")')
    assert not fp.is_moonveil


# ---- loop reconstruction ---------------------------------------------------

def test_recovers_rolled_loop():
    # synthetic samples use Lua 5.3+ syntax -> pin the lupa backend
    rep = pipeline.devirtualize(_read("synth_vm.lua"), sample_name="synth_vm.lua", backend="lupa")
    assert rep.run.ok
    out = rep.reconstructed
    assert "for i = 1, 3 do" in out
    assert 'print(i, "hello from moonveil")' in out


def test_constant_decrypted():
    # the string constant is xor-encrypted in the sample; behavior must show plaintext
    rep = pipeline.devirtualize(_read("synth_vm.lua"), backend="lupa")
    joined = " ".join(e.call_source() for e in rep.run.events)
    assert "hello from moonveil" in joined


def test_dispatcher_detected():
    rep = pipeline.devirtualize(_read("synth_vm.lua"), backend="lupa")
    assert rep.run.hot_line is not None
    assert rep.run.hot_count > 5  # the VM loop ran many times


# ---- triage view -----------------------------------------------------------

def test_exfil_triage():
    rep = pipeline.devirtualize(_read("synth_exfil.lua"), fill_globals=True, backend="lupa")
    cats = {e.category for e in rep.run.events}
    assert {"network", "filesystem", "codeload"} <= cats
    out = rep.reconstructed
    assert "behavior summary" in out
    assert "discord.com/api/webhooks" in out
    assert "readfile" in out


def test_no_real_side_effects(tmp_path):
    # running the exfil sample must NOT create the file it "writes"
    before = set(os.listdir("."))
    pipeline.devirtualize(_read("synth_exfil.lua"), fill_globals=True, backend="lupa")
    assert not os.path.exists("exfil_done.txt")
    assert set(os.listdir(".")) == before


def test_io_is_sealed():
    rep = pipeline.devirtualize('io = io or nil; print(tostring(io))', backend="lupa")
    # io must be unavailable inside the sandbox
    assert any(e.name == "print" and e.args and e.args[0] == "nil" for e in rep.run.events)


# ---- anti-hang guard -------------------------------------------------------

def test_step_budget_aborts():
    r = sandbox.run("while true do end", step_budget=2000)
    assert r.overrun
    assert not r.ok


# ---- real Luau backend on the actual MoonVeil sample -----------------------

def test_real_moonveil_under_luau():
    from moonveildevirt import luaubackend
    if not os.path.exists(os.path.join(SAMPLES, "real_sample.lua")):
        pytest.skip("real MoonVeil sample not present")
    if not luaubackend.ensure_luau(auto_download=True):
        pytest.skip("luau binary unavailable (no download)")
    rep = pipeline.devirtualize(_read("real_sample.lua"), backend="luau",
                                sample_name="real_sample.lua", timeout=120)
    assert rep.backend == "luau"
    assert rep.run.ok
    names = " ".join(e.call_source() for e in rep.run.events)
    # key-gate behavior we recovered: PolSec warn + Kick + hang loop
    assert "PolSec" in names
    assert "Kick" in names
    assert getattr(rep.run, "limited", False)  # hangs on wait loop
    assert "busy/hang loop" in rep.reconstructed


# ---- pure-unit reconstruction (no lua needed for this logic) ---------------

def test_arg_progression_expr():
    from moonveildevirt.reconstruct import _arg_expr
    assert _arg_expr("i", [1, 2, 3]) == "i"
    assert _arg_expr("i", [5, 5, 5]) == "5"
    assert _arg_expr("i", [2, 3, 4]) == "(i + 1)"
    assert _arg_expr("i", [0, 2, 4]) == "((i - 1) * 2)"
    assert _arg_expr("i", ["a", "b"]) is None


def test_roll_from_synthetic_events():
    evs = [Event(i + 1, "output", "print", [i + 1, "x"]) for i in range(4)]
    r = reconstruct.RunResult(events=evs)
    out = reconstruct.reconstruct(r)
    assert "for i = 1, 4 do" in out
    assert 'print(i, "x")' in out
